#include<Servo.h>
Servo servo1;
int trigger=4;
int echo=5;
long duration;
int distance;
int dist;

int readDistance(){
   digitalWrite(trigger,HIGH);
   delayMicroseconds(10);
   digitalWrite(trigger,LOW);
   duration=pulseIn(echo,HIGH);
   distance=duration*0.034/2;
   return distance;
}

void setup() {
  // put your setup code here, to run once:
  servo1.attach(3);
  pinMode(echo,INPUT);
  pinMode(trigger,OUTPUT);
  Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
   for(int i=15;i<=165;i++){
    servo1.write(i);
    delay(30);
    dist=readDistance();
    Serial.println(i);
    Serial.println(",");
    Serial.println(dist);
    Serial.println(".");
   }
   for(int i=165;i>=15;i--){
     servo1.write(i);
     delay(30);
     dist=readDistance();
     Serial.print(i);
    Serial.println(",");
    Serial.println(dist);
    Serial.println(".");
   }  
}
